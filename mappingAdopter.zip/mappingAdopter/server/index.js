import cors from "cors";
import express from "express";
import { db } from "./db.js";

const app = express();
const PORT = Number(process.env.API_PORT || 4100);

app.use(cors());
app.use(express.json({ limit: "2mb" }));

const canonicalFields = ["studyId", "country", "participantCount"];

function parseCsv(csvText) {
  const lines = csvText
    .split(/\r?\n/)
    .map((line) => line.trim())
    .filter(Boolean);

  if (lines.length === 0) {
    return [];
  }

  const headers = lines[0].split(",").map((h) => h.trim());
  const rows = [];

  for (let i = 1; i < lines.length; i += 1) {
    const cols = lines[i].split(",").map((c) => c.trim());
    const row = {};
    headers.forEach((header, idx) => {
      row[header] = cols[idx] ?? "";
    });
    rows.push(row);
  }

  return rows;
}

function normalizeField(value) {
  return String(value ?? "").replace(/[^a-zA-Z0-9]/g, "").toLowerCase();
}

function suggestCanonicalField(sourceField) {
  const key = normalizeField(sourceField);
  const dictionary = [
    { canonical: "studyId", aliases: ["studyid", "studynumber", "trialno", "trialnumber"] },
    { canonical: "country", aliases: ["country", "countryname", "nation"] },
    { canonical: "participantCount", aliases: ["participantcount", "patientcount", "participants", "totalsubjects"] },
  ];

  for (const item of dictionary) {
    if (item.aliases.includes(key)) {
      return {
        canonicalField: item.canonical,
        confidence: 0.9,
        reason: `Alias match for ${sourceField}`,
      };
    }
  }

  if (key.includes("study") || key.includes("trial")) {
    return { canonicalField: "studyId", confidence: 0.62, reason: "Keyword heuristic: study/trial" };
  }
  if (key.includes("country") || key.includes("nation")) {
    return { canonicalField: "country", confidence: 0.62, reason: "Keyword heuristic: country/nation" };
  }
  if (key.includes("patient") || key.includes("subject") || key.includes("participant")) {
    return {
      canonicalField: "participantCount",
      confidence: 0.62,
      reason: "Keyword heuristic: participant/patient/subject",
    };
  }

  return null;
}

function getActiveMappings(sourceName) {
  const rows = db
    .prepare(
      `SELECT source_field, canonical_field
       FROM field_mappings
       WHERE source_name = ? AND status = 'ACTIVE'`,
    )
    .all(sourceName);

  const map = new Map();
  rows.forEach((row) => {
    map.set(row.source_field, row.canonical_field);
  });
  return map;
}

function mapRecord(sourceName, record, mappingMap) {
  const canonical = {};
  const suggestions = [];

  for (const [sourceField, value] of Object.entries(record)) {
    const mapped = mappingMap.get(sourceField);

    if (mapped) {
      canonical[mapped] = value;
      continue;
    }

    const suggestion = suggestCanonicalField(sourceField);
    if (suggestion) {
      suggestions.push({
        sourceName,
        sourceField,
        suggestedCanonicalField: suggestion.canonicalField,
        confidence: suggestion.confidence,
        reason: suggestion.reason,
      });
    }
  }

  return { canonical, suggestions };
}

function validateCanonical(record) {
  const errors = [];

  if (!String(record.studyId ?? "").trim()) {
    errors.push("studyId is required");
  }

  if (!String(record.country ?? "").trim()) {
    errors.push("country is required");
  }

  const participantCount = Number(record.participantCount);
  if (!Number.isFinite(participantCount)) {
    errors.push("participantCount must be a number");
  } else if (participantCount < 0) {
    errors.push("participantCount must be >= 0");
  }

  return {
    ok: errors.length === 0,
    errors,
    normalized: {
      studyId: String(record.studyId ?? "").trim(),
      country: String(record.country ?? "").trim(),
      participantCount: Number(record.participantCount),
    },
  };
}

function persistSuggestion(suggestion) {
  const exists = db
    .prepare(
      `SELECT id FROM mapping_suggestions
       WHERE source_name = ? AND source_field = ? AND status = 'PENDING'`,
    )
    .get(suggestion.sourceName, suggestion.sourceField);

  if (exists) return;

  db.prepare(
    `INSERT INTO mapping_suggestions (
      source_name, source_field, suggested_canonical_field, confidence, reason, status, created_at
    ) VALUES (?, ?, ?, ?, ?, 'PENDING', ?)`,
  ).run(
    suggestion.sourceName,
    suggestion.sourceField,
    suggestion.suggestedCanonicalField,
    suggestion.confidence,
    suggestion.reason,
    new Date().toISOString(),
  );
}

function upsertStudyRecord(sourceName, normalized) {
  const now = new Date().toISOString();
  const existing = db.prepare("SELECT * FROM study_records WHERE study_id = ?").get(normalized.studyId);

  if (!existing) {
    db.prepare(
      `INSERT INTO study_records (
        study_id, country, participant_count, source_name, version, created_at, updated_at
      ) VALUES (?, ?, ?, ?, 1, ?, ?)`,
    ).run(normalized.studyId, normalized.country, normalized.participantCount, sourceName, now, now);

    db.prepare(
      `INSERT INTO study_change_log (study_id, change_type, source_name, before_json, after_json, changed_at)
       VALUES (?, 'CREATE', ?, NULL, ?, ?)`,
    ).run(normalized.studyId, sourceName, JSON.stringify(normalized), now);

    return;
  }

  const before = {
    studyId: existing.study_id,
    country: existing.country,
    participantCount: existing.participant_count,
  };

  const changed =
    before.country !== normalized.country || before.participantCount !== normalized.participantCount;

  if (!changed) {
    return;
  }

  db.prepare(
    `UPDATE study_records
     SET country = ?, participant_count = ?, source_name = ?, version = version + 1, updated_at = ?
     WHERE study_id = ?`,
  ).run(normalized.country, normalized.participantCount, sourceName, now, normalized.studyId);

  db.prepare(
    `INSERT INTO study_change_log (study_id, change_type, source_name, before_json, after_json, changed_at)
     VALUES (?, 'UPDATE', ?, ?, ?, ?)`,
  ).run(normalized.studyId, sourceName, JSON.stringify(before), JSON.stringify(normalized), now);
}

app.get("/api/health", (_req, res) => {
  res.json({ ok: true, service: "mapping-adopter-api" });
});

app.get("/api/mappings", (_req, res) => {
  const rows = db
    .prepare(
      `SELECT id, source_name, source_field, canonical_field, status, created_at
       FROM field_mappings
       ORDER BY source_name, source_field`,
    )
    .all();
  res.json(rows);
});

app.get("/api/suggestions", (_req, res) => {
  const rows = db
    .prepare(
      `SELECT id, source_name, source_field, suggested_canonical_field, confidence, reason, status, created_at, reviewed_at
       FROM mapping_suggestions
       ORDER BY id DESC`,
    )
    .all();
  res.json(rows);
});

app.post("/api/suggestions/:id/approve", (req, res) => {
  const id = Number(req.params.id);
  const suggestion = db.prepare("SELECT * FROM mapping_suggestions WHERE id = ?").get(id);

  if (!suggestion) {
    res.status(404).json({ message: "Suggestion not found" });
    return;
  }

  if (suggestion.status !== "PENDING") {
    res.status(400).json({ message: "Suggestion already reviewed" });
    return;
  }

  const now = new Date().toISOString();

  const tx = db.transaction(() => {
    db.prepare(
      `INSERT INTO field_mappings (source_name, source_field, canonical_field, status, created_at)
       VALUES (?, ?, ?, 'ACTIVE', ?)
       ON CONFLICT(source_name, source_field)
       DO UPDATE SET canonical_field = excluded.canonical_field, status = 'ACTIVE'`,
    ).run(suggestion.source_name, suggestion.source_field, suggestion.suggested_canonical_field, now);

    db.prepare("UPDATE mapping_suggestions SET status = 'APPROVED', reviewed_at = ? WHERE id = ?").run(now, id);
  });

  tx();

  res.json({ message: "Suggestion approved and mapping activated" });
});

app.post("/api/suggestions/:id/reject", (req, res) => {
  const id = Number(req.params.id);
  const suggestion = db.prepare("SELECT * FROM mapping_suggestions WHERE id = ?").get(id);

  if (!suggestion) {
    res.status(404).json({ message: "Suggestion not found" });
    return;
  }

  if (suggestion.status !== "PENDING") {
    res.status(400).json({ message: "Suggestion already reviewed" });
    return;
  }

  db.prepare("UPDATE mapping_suggestions SET status = 'REJECTED', reviewed_at = ? WHERE id = ?").run(
    new Date().toISOString(),
    id,
  );

  res.json({ message: "Suggestion rejected" });
});

app.post("/api/ingest", (req, res) => {
  const body = req.body ?? {};
  const sourceName = String(body.sourceName ?? "").trim();
  const sourceType = String(body.sourceType ?? "json").trim().toLowerCase();

  if (!sourceName) {
    res.status(400).json({ message: "sourceName is required" });
    return;
  }

  let records = [];

  if (sourceType === "json") {
    if (!Array.isArray(body.records)) {
      res.status(400).json({ message: "records must be an array for json sourceType" });
      return;
    }
    records = body.records;
  } else if (sourceType === "csv") {
    const csvText = String(body.csvText ?? "");
    if (!csvText.trim()) {
      res.status(400).json({ message: "csvText is required for csv sourceType" });
      return;
    }
    records = parseCsv(csvText);
  } else {
    res.status(400).json({ message: "sourceType must be json or csv" });
    return;
  }

  const mappingMap = getActiveMappings(sourceName);
  const invalid = [];
  const valid = [];
  const suggestionCollector = [];

  for (let i = 0; i < records.length; i += 1) {
    const sourceRecord = records[i];
    const { canonical, suggestions } = mapRecord(sourceName, sourceRecord, mappingMap);

    suggestions.forEach((item) => suggestionCollector.push(item));

    const validation = validateCanonical(canonical);
    if (!validation.ok) {
      invalid.push({ index: i, sourceRecord, errors: validation.errors });
      continue;
    }

    valid.push(validation.normalized);
  }

  const tx = db.transaction(() => {
    for (const suggestion of suggestionCollector) {
      persistSuggestion(suggestion);
    }

    for (const row of valid) {
      upsertStudyRecord(sourceName, row);
    }

    db.prepare(
      `INSERT INTO ingestion_runs (source_name, received_records, valid_records, invalid_records, created_at)
       VALUES (?, ?, ?, ?, ?)`,
    ).run(sourceName, records.length, valid.length, invalid.length, new Date().toISOString());
  });

  tx();

  res.json({
    sourceName,
    sourceType,
    receivedRecords: records.length,
    validRecords: valid.length,
    invalidRecords: invalid.length,
    invalid,
    aiSuggestionsGenerated: suggestionCollector.length,
  });
});

app.get("/api/studies", (_req, res) => {
  const rows = db
    .prepare(
      `SELECT study_id, country, participant_count, source_name, version, created_at, updated_at
       FROM study_records
       ORDER BY updated_at DESC`,
    )
    .all();

  const payload = rows.map((row) => ({
    studyId: row.study_id,
    country: row.country,
    participantCount: row.participant_count,
    sourceName: row.source_name,
    version: row.version,
    createdAt: row.created_at,
    updatedAt: row.updated_at,
  }));

  res.json(payload);
});

app.get("/api/changelog", (_req, res) => {
  const rows = db
    .prepare(
      `SELECT study_id, change_type, source_name, before_json, after_json, changed_at
       FROM study_change_log
       ORDER BY id DESC`,
    )
    .all();

  const payload = rows.map((row) => ({
    studyId: row.study_id,
    changeType: row.change_type,
    sourceName: row.source_name,
    before: row.before_json ? JSON.parse(row.before_json) : null,
    after: row.after_json ? JSON.parse(row.after_json) : null,
    changedAt: row.changed_at,
  }));

  res.json(payload);
});

app.get("/api/ingestion-runs", (_req, res) => {
  const rows = db
    .prepare(
      `SELECT id, source_name, received_records, valid_records, invalid_records, created_at
       FROM ingestion_runs
       ORDER BY id DESC`,
    )
    .all();

  res.json(rows);
});

app.listen(PORT, () => {
  console.log(`API running on http://localhost:${PORT}`);
});
