import Database from "better-sqlite3";
import fs from "node:fs";
import path from "node:path";

const dataDir = path.resolve(process.cwd(), "data");
if (!fs.existsSync(dataDir)) {
  fs.mkdirSync(dataDir, { recursive: true });
}

const dbPath = path.join(dataDir, "mapping-adopter.db");
export const db = new Database(dbPath);

db.pragma("journal_mode = WAL");

db.exec(`
  CREATE TABLE IF NOT EXISTS field_mappings (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    source_name TEXT NOT NULL,
    source_field TEXT NOT NULL,
    canonical_field TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'ACTIVE',
    created_at TEXT NOT NULL,
    UNIQUE(source_name, source_field)
  );

  CREATE TABLE IF NOT EXISTS mapping_suggestions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    source_name TEXT NOT NULL,
    source_field TEXT NOT NULL,
    suggested_canonical_field TEXT NOT NULL,
    confidence REAL NOT NULL,
    reason TEXT,
    status TEXT NOT NULL DEFAULT 'PENDING',
    created_at TEXT NOT NULL,
    reviewed_at TEXT
  );

  CREATE TABLE IF NOT EXISTS study_records (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    study_id TEXT NOT NULL UNIQUE,
    country TEXT NOT NULL,
    participant_count INTEGER NOT NULL,
    source_name TEXT NOT NULL,
    version INTEGER NOT NULL DEFAULT 1,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
  );

  CREATE TABLE IF NOT EXISTS study_change_log (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    study_id TEXT NOT NULL,
    change_type TEXT NOT NULL,
    source_name TEXT NOT NULL,
    before_json TEXT,
    after_json TEXT,
    changed_at TEXT NOT NULL
  );

  CREATE TABLE IF NOT EXISTS ingestion_runs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    source_name TEXT NOT NULL,
    received_records INTEGER NOT NULL,
    valid_records INTEGER NOT NULL,
    invalid_records INTEGER NOT NULL,
    created_at TEXT NOT NULL
  );
`);

function seedMappings() {
  const count = db.prepare("SELECT COUNT(*) AS count FROM field_mappings").get()?.count ?? 0;
  if (count > 0) return;

  const now = new Date().toISOString();
  const insert = db.prepare(
    `INSERT INTO field_mappings (source_name, source_field, canonical_field, status, created_at)
     VALUES (?, ?, ?, 'ACTIVE', ?)`,
  );

  const entries = [
    ["SourceA", "Study_ID", "studyId"],
    ["SourceA", "Country", "country"],
    ["SourceA", "Patient_Count", "participantCount"],
    ["SourceB", "StudyNumber", "studyId"],
    ["SourceB", "CountryName", "country"],
    ["SourceB", "Participants", "participantCount"],
  ];

  const tx = db.transaction(() => {
    for (const [sourceName, sourceField, canonicalField] of entries) {
      insert.run(sourceName, sourceField, canonicalField, now);
    }
  });

  tx();
}

seedMappings();
