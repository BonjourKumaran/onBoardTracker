import { useEffect, useMemo, useState } from 'react'
import './App.css'

type IngestResponse = {
  sourceName: string
  sourceType: string
  receivedRecords: number
  validRecords: number
  invalidRecords: number
  invalid: Array<{ index: number; sourceRecord: Record<string, unknown>; errors: string[] }>
  aiSuggestionsGenerated: number
}

type StudyRecord = {
  studyId: string
  country: string
  participantCount: number
  sourceName: string
  version: number
  createdAt: string
  updatedAt: string
}

type Suggestion = {
  id: number
  source_name: string
  source_field: string
  suggested_canonical_field: string
  confidence: number
  reason: string
  status: 'PENDING' | 'APPROVED' | 'REJECTED'
  created_at: string
  reviewed_at: string | null
}

type ChangeLog = {
  studyId: string
  changeType: string
  sourceName: string
  before: Record<string, unknown> | null
  after: Record<string, unknown> | null
  changedAt: string
}

const sampleJson = `[
  { "Study_ID": "ST-901", "Country": "India", "Patient_Count": 120 },
  { "Study_ID": "ST-902", "Country": "Japan", "Patient_Count": 80 }
]`

const sampleCsv = `StudyNumber,CountryName,Participants\nST-903,France,67\nST-904,Brazil,49`

function App() {
  const [sourceName, setSourceName] = useState('SourceA')
  const [sourceType, setSourceType] = useState<'json' | 'csv'>('json')
  const [payloadText, setPayloadText] = useState(sampleJson)
  const [ingestResult, setIngestResult] = useState<IngestResponse | null>(null)
  const [studies, setStudies] = useState<StudyRecord[]>([])
  const [suggestions, setSuggestions] = useState<Suggestion[]>([])
  const [changeLog, setChangeLog] = useState<ChangeLog[]>([])
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')

  const pendingSuggestions = useMemo(
    () => suggestions.filter((item) => item.status === 'PENDING'),
    [suggestions],
  )

  async function loadAll() {
    const [studyRes, suggestionRes, changeRes] = await Promise.all([
      fetch('/api/studies'),
      fetch('/api/suggestions'),
      fetch('/api/changelog'),
    ])

    if (!studyRes.ok || !suggestionRes.ok || !changeRes.ok) {
      throw new Error('Failed to load dashboard data')
    }

    setStudies(await studyRes.json())
    setSuggestions(await suggestionRes.json())
    setChangeLog(await changeRes.json())
  }

  useEffect(() => {
    loadAll().catch((e: unknown) => {
      setError(e instanceof Error ? e.message : 'Failed to load data')
    })
  }, [])

  async function ingest() {
    setLoading(true)
    setError('')
    setIngestResult(null)

    try {
      const body =
        sourceType === 'json'
          ? { sourceName, sourceType, records: JSON.parse(payloadText) }
          : { sourceName, sourceType, csvText: payloadText }

      const res = await fetch('/api/ingest', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body),
      })

      if (!res.ok) {
        const payload = await res.json().catch(() => ({}))
        throw new Error(payload.message || 'Ingestion failed')
      }

      const data = (await res.json()) as IngestResponse
      setIngestResult(data)
      await loadAll()
    } catch (e: unknown) {
      setError(e instanceof Error ? e.message : 'Ingestion failed')
    } finally {
      setLoading(false)
    }
  }

  async function reviewSuggestion(id: number, action: 'approve' | 'reject') {
    setLoading(true)
    setError('')
    try {
      const res = await fetch(`/api/suggestions/${id}/${action}`, { method: 'POST' })
      if (!res.ok) {
        const payload = await res.json().catch(() => ({}))
        throw new Error(payload.message || `Failed to ${action} suggestion`)
      }
      await loadAll()
    } catch (e: unknown) {
      setError(e instanceof Error ? e.message : 'Failed to review suggestion')
    } finally {
      setLoading(false)
    }
  }

  return (
    <main className="page">
      <header className="hero">
        <div>
          <p className="eyebrow">Exercise 2</p>
          <h1>Mapping Adopter Service</h1>
          <p className="subhead">
            Ingest source datasets, normalize them into canonical fields, validate quality, and review AI
            mapping suggestions.
          </p>
        </div>
        <div className="hero-stat">
          <p>Canonical records</p>
          <strong>{studies.length}</strong>
        </div>
        <div className="hero-stat">
          <p>Pending mapping reviews</p>
          <strong>{pendingSuggestions.length}</strong>
        </div>
      </header>

      <section className="panel">
        <h2>Source Ingestion</h2>
        <div className="form-grid">
          <label>
            Source Name
            <input value={sourceName} onChange={(e) => setSourceName(e.target.value)} />
          </label>
          <label>
            Source Type
            <select
              value={sourceType}
              onChange={(e) => {
                const next = e.target.value as 'json' | 'csv'
                setSourceType(next)
                setPayloadText(next === 'json' ? sampleJson : sampleCsv)
              }}
            >
              <option value="json">JSON</option>
              <option value="csv">CSV</option>
            </select>
          </label>
        </div>
        <label className="block">
          Payload
          <textarea
            value={payloadText}
            onChange={(e) => setPayloadText(e.target.value)}
            rows={8}
            spellCheck={false}
          />
        </label>
        <div className="actions">
          <button disabled={loading} onClick={ingest} type="button">
            {loading ? 'Processing...' : 'Ingest Dataset'}
          </button>
        </div>
        {error ? <p className="error">{error}</p> : null}
        {ingestResult ? (
          <div className="result">
            <p>
              Received: <strong>{ingestResult.receivedRecords}</strong> | Valid:{' '}
              <strong>{ingestResult.validRecords}</strong> | Invalid:{' '}
              <strong>{ingestResult.invalidRecords}</strong> | Suggestions Generated:{' '}
              <strong>{ingestResult.aiSuggestionsGenerated}</strong>
            </p>
            {ingestResult.invalid.length > 0 ? (
              <ul>
                {ingestResult.invalid.map((item) => (
                  <li key={item.index}>
                    Row {item.index + 1}: {item.errors.join(', ')}
                  </li>
                ))}
              </ul>
            ) : null}
          </div>
        ) : null}
      </section>

      <section className="split">
        <div className="panel">
          <h2>Approved Canonical Records</h2>
          <div className="table-wrap">
            <table>
              <thead>
                <tr>
                  <th>Study ID</th>
                  <th>Country</th>
                  <th>Participant Count</th>
                  <th>Source</th>
                  <th>Version</th>
                </tr>
              </thead>
              <tbody>
                {studies.map((record) => (
                  <tr key={record.studyId}>
                    <td>{record.studyId}</td>
                    <td>{record.country}</td>
                    <td>{record.participantCount}</td>
                    <td>{record.sourceName}</td>
                    <td>{record.version}</td>
                  </tr>
                ))}
                {studies.length === 0 ? (
                  <tr>
                    <td colSpan={5}>No canonical records yet.</td>
                  </tr>
                ) : null}
              </tbody>
            </table>
          </div>
        </div>

        <div className="panel">
          <h2>AI Mapping Suggestions</h2>
          <div className="suggestions">
            {suggestions.map((item) => (
              <article key={item.id} className="suggestion">
                <p>
                  <strong>{item.source_name}</strong> field <code>{item.source_field}</code> →{' '}
                  <code>{item.suggested_canonical_field}</code>
                </p>
                <p>
                  Confidence: {(item.confidence * 100).toFixed(0)}% | Status: {item.status}
                </p>
                <p>{item.reason}</p>
                {item.status === 'PENDING' ? (
                  <div className="actions">
                    <button
                      disabled={loading}
                      type="button"
                      onClick={() => reviewSuggestion(item.id, 'approve')}
                    >
                      Approve
                    </button>
                    <button
                      disabled={loading}
                      className="danger"
                      type="button"
                      onClick={() => reviewSuggestion(item.id, 'reject')}
                    >
                      Reject
                    </button>
                  </div>
                ) : null}
              </article>
            ))}
            {suggestions.length === 0 ? <p>No suggestions yet.</p> : null}
          </div>
        </div>
      </section>

      <section className="panel">
        <h2>Immutable Change Log</h2>
        <div className="timeline">
          {changeLog.map((item, idx) => (
            <article key={`${item.studyId}-${item.changedAt}-${idx}`} className="timeline-item">
              <p>
                <strong>{item.changeType}</strong> for <code>{item.studyId}</code> by {item.sourceName}
              </p>
              <p>{new Date(item.changedAt).toLocaleString()}</p>
            </article>
          ))}
          {changeLog.length === 0 ? <p>No changes captured yet.</p> : null}
        </div>
      </section>
    </main>
  )
}

export default App
