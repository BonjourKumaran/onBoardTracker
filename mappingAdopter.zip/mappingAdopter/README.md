# Mapping Adopter (Exercise 2)

This project implements a small AI-assisted data harmonization service.

## Important Flow Only

- Accepts source datasets in JSON or CSV format.
- Uses source-specific adapters to convert fields into canonical schema:
  - `studyId`
  - `country`
  - `participantCount`
- Validates canonical records before persistence.
- Stores canonical records in SQLite.
- Captures immutable change log entries for create/update events.
- Uses AI suggestions only for unknown source fields.
- Requires explicit review and approval before a suggested mapping becomes active.

## Architecture

- Frontend: React + TypeScript + Vite
- Backend API: Express
- Database: SQLite (`better-sqlite3`)

Flow:
1. Ingest source payload (`/api/ingest`)
2. Apply source adapter mappings (`field_mappings`)
3. Validate canonical records
4. Persist canonical records (`study_records`)
5. Append immutable change events (`study_change_log`)
6. Queue AI suggestions (`mapping_suggestions`) for reviewer action

## Run Locally

```bash
cd /Users/kumaranr/mappingAdopter
npm install
npm run dev:all
```

- UI: http://localhost:5173
- API: http://localhost:4100

## Build

```bash
npm run build
```

## Key Endpoints (Core)

- `POST /api/ingest` - Ingest JSON or CSV datasets
- `GET /api/studies` - Canonical records
- `GET /api/changelog` - Immutable change history
- `GET /api/mappings` - Active source mappings
- `GET /api/suggestions` - AI mapping suggestions
- `POST /api/suggestions/:id/approve` - Approve and activate suggested mapping
- `POST /api/suggestions/:id/reject` - Reject suggestion

## Example Payloads

JSON ingest:

```json
{
  "sourceName": "SourceA",
  "sourceType": "json",
  "records": [
    { "Study_ID": "ST-901", "Country": "India", "Patient_Count": 120 }
  ]
}
```

CSV ingest:

```json
{
  "sourceName": "SourceB",
  "sourceType": "csv",
  "csvText": "StudyNumber,CountryName,Participants\nST-903,France,67"
}
```

Unknown source (AI-assisted review flow):

```json
{
  "sourceName": "SourceC",
  "sourceType": "json",
  "records": [
    { "TrialNo": "TR-1001", "Nation": "Germany", "TotalSubjects": 42 }
  ]
}
```

Expected behavior for SourceC:
1. First ingest: system creates mapping suggestions for unknown fields and does not auto-activate them.
2. Review step: approve suggestions such as TrialNo -> studyId, Nation -> country, TotalSubjects -> participantCount.
3. Re-ingest same payload: approved mappings are applied, validation passes, and record is stored in canonical table.

## Notes

- AI-assisted mapping in this implementation uses deterministic heuristic rules (alias and keyword matching).
- No trained ML model or external LLM API is used in the current version.
- Security, auth, and enterprise identity integrations are intentionally out of scope for this exercise.
- Pagination, advanced search, and other non-core UI scenarios are intentionally out of scope.
