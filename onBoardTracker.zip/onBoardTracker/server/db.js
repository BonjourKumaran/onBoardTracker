import Database from "better-sqlite3";
import fs from "node:fs";
import path from "node:path";

const dataDir = path.resolve(process.cwd(), "data");
if (!fs.existsSync(dataDir)) {
  fs.mkdirSync(dataDir, { recursive: true });
}

const dbPath = path.join(dataDir, "onboard-tracker.db");
export const db = new Database(dbPath);

db.pragma("journal_mode = WAL");

db.exec(`
  CREATE TABLE IF NOT EXISTS sites (
    id TEXT PRIMARY KEY,
    site_name TEXT NOT NULL,
    site_code TEXT NOT NULL UNIQUE,
    region TEXT NOT NULL,
    address TEXT,
    requester TEXT NOT NULL,
    requester_email TEXT NOT NULL,
    submitted_at TEXT NOT NULL,
    status TEXT NOT NULL,
    current_stage TEXT NOT NULL,
    legal_approval TEXT,
    compliance_approval TEXT,
    site_ops_approval TEXT,
    rejection_reason TEXT,
    version INTEGER NOT NULL DEFAULT 1
  );

  CREATE TABLE IF NOT EXISTS audit_logs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    site_id TEXT NOT NULL,
    at TEXT NOT NULL,
    by_role TEXT NOT NULL,
    action TEXT NOT NULL,
    note TEXT,
    from_status TEXT NOT NULL,
    to_status TEXT NOT NULL,
    FOREIGN KEY(site_id) REFERENCES sites(id)
  );

  CREATE TABLE IF NOT EXISTS notification_logs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    site_id TEXT NOT NULL,
    at TEXT NOT NULL,
    recipient_role TEXT NOT NULL,
    channel TEXT NOT NULL,
    message TEXT NOT NULL,
    FOREIGN KEY(site_id) REFERENCES sites(id)
  );
`);

function seedIfEmpty() {
  const row = db.prepare("SELECT COUNT(*) AS count FROM sites").get();
  if ((row?.count ?? 0) > 0) {
    return;
  }

  const insertSite = db.prepare(`
    INSERT INTO sites (
      id, site_name, site_code, region, address, requester, requester_email,
      submitted_at, status, current_stage, legal_approval, compliance_approval,
      site_ops_approval, rejection_reason, version
    ) VALUES (
      @id, @site_name, @site_code, @region, @address, @requester, @requester_email,
      @submitted_at, @status, @current_stage, @legal_approval, @compliance_approval,
      @site_ops_approval, @rejection_reason, @version
    )
  `);

  const insertAudit = db.prepare(`
    INSERT INTO audit_logs (site_id, at, by_role, action, note, from_status, to_status)
    VALUES (@site_id, @at, @by_role, @action, @note, @from_status, @to_status)
  `);

  const seedSites = [
    {
      id: "S-001",
      site_name: "North Ridge Data Hub",
      site_code: "NRD-101",
      region: "North",
      address: "Whitefield, Bengaluru",
      requester: "Arun Kumar",
      requester_email: "arun.kumar@example.com",
      submitted_at: "2026-09-22T09:15:00.000Z",
      status: "Compliance Pending",
      current_stage: "Compliance",
      legal_approval: "Approved",
      compliance_approval: null,
      site_ops_approval: null,
      rejection_reason: null,
      version: 2,
      audit: [
        {
          at: "2026-09-22T09:15:00.000Z",
          by_role: "Requester",
          action: "Submitted",
          note: "Site onboarding request created.",
          from_status: "Pending",
          to_status: "Legal Pending",
        },
        {
          at: "2026-09-22T11:00:00.000Z",
          by_role: "Legal",
          action: "Approved",
          note: "Legal documents are valid.",
          from_status: "Legal Pending",
          to_status: "Compliance Pending",
        },
      ],
    },
    {
      id: "S-002",
      site_name: "Coastal Operations Point",
      site_code: "COP-204",
      region: "South",
      address: "Thiruvanmiyur, Chennai",
      requester: "Meera Iyer",
      requester_email: "meera.iyer@example.com",
      submitted_at: "2026-09-23T14:32:00.000Z",
      status: "Site Ops Pending",
      current_stage: "SiteOps",
      legal_approval: "Approved",
      compliance_approval: "Approved",
      site_ops_approval: null,
      rejection_reason: null,
      version: 3,
      audit: [
        {
          at: "2026-09-23T14:32:00.000Z",
          by_role: "Requester",
          action: "Submitted",
          note: "Site onboarding request created.",
          from_status: "Pending",
          to_status: "Legal Pending",
        },
        {
          at: "2026-09-23T16:10:00.000Z",
          by_role: "Legal",
          action: "Approved",
          note: null,
          from_status: "Legal Pending",
          to_status: "Compliance Pending",
        },
        {
          at: "2026-09-24T10:22:00.000Z",
          by_role: "Compliance",
          action: "Approved",
          note: null,
          from_status: "Compliance Pending",
          to_status: "Site Ops Pending",
        },
      ],
    },
  ];

  const tx = db.transaction(() => {
    for (const site of seedSites) {
      insertSite.run(site);
      for (const entry of site.audit) {
        insertAudit.run({ site_id: site.id, ...entry });
      }
    }
  });

  tx();
}

seedIfEmpty();
