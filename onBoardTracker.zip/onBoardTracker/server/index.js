import cors from "cors";
import express from "express";
import { db } from "./db.js";

const app = express();
const PORT = Number(process.env.API_PORT || 4000);

app.use(cors());
app.use(express.json());

const allowedRoles = new Set(["Requester", "Legal", "Compliance", "SiteOps"]);

function mapSiteRow(row) {
  return {
    id: row.id,
    siteName: row.site_name,
    siteCode: row.site_code,
    region: row.region,
    address: row.address,
    requester: row.requester,
    requesterEmail: row.requester_email,
    submittedAt: row.submitted_at,
    status: row.status,
    currentStage: row.current_stage,
    legalApproval: row.legal_approval ?? undefined,
    complianceApproval: row.compliance_approval ?? undefined,
    siteOpsApproval: row.site_ops_approval ?? undefined,
    rejectionReason: row.rejection_reason ?? undefined,
    version: row.version,
  };
}

function getSiteAudit(siteId) {
  const rows = db
    .prepare(
      `SELECT at, by_role, action, note, from_status, to_status
       FROM audit_logs
       WHERE site_id = ?
       ORDER BY id DESC`,
    )
    .all(siteId);

  return rows.map((row) => ({
    at: row.at,
    by: row.by_role,
    action: row.action,
    note: row.note ?? undefined,
    fromStatus: row.from_status,
    toStatus: row.to_status,
  }));
}

function getSiteById(siteId) {
  const row = db.prepare("SELECT * FROM sites WHERE id = ?").get(siteId);
  if (!row) {
    return null;
  }

  return {
    ...mapSiteRow(row),
    audit: getSiteAudit(siteId),
  };
}

function roleCanAct(role, site) {
  if (site.status === "Completed" || site.status === "Rejected") {
    return false;
  }

  return (
    (site.current_stage === "Legal" && role === "Legal") ||
    (site.current_stage === "Compliance" && role === "Compliance") ||
    (site.current_stage === "SiteOps" && role === "SiteOps")
  );
}

function nextOnApprove(site) {
  if (site.current_stage === "Legal") {
    return { stage: "Compliance", status: "Compliance Pending" };
  }

  if (site.current_stage === "Compliance") {
    return { stage: "SiteOps", status: "Site Ops Pending" };
  }

  return { stage: "Done", status: "Completed" };
}

function recipientRoleForPendingStatus(status) {
  if (status === "Legal Pending") return "Legal";
  if (status === "Compliance Pending") return "Compliance";
  if (status === "Site Ops Pending") return "SiteOps";
  return null;
}

function generateSiteId() {
  const row = db.prepare("SELECT COUNT(*) AS count FROM sites").get();
  const num = (row?.count ?? 0) + 1;
  return `S-${String(num).padStart(3, "0")}`;
}

app.get("/api/health", (_req, res) => {
  res.json({ ok: true, service: "onBoardTracker-api" });
});

app.get("/api/dashboard", (_req, res) => {
  const total = db.prepare("SELECT COUNT(*) AS count FROM sites").get()?.count ?? 0;
  const completed = db.prepare("SELECT COUNT(*) AS count FROM sites WHERE status = 'Completed'").get()?.count ?? 0;
  const rejected = db.prepare("SELECT COUNT(*) AS count FROM sites WHERE status = 'Rejected'").get()?.count ?? 0;
  const pending = db
    .prepare("SELECT COUNT(*) AS count FROM sites WHERE status NOT IN ('Completed', 'Rejected')")
    .get()?.count ?? 0;

  res.json({ total, pending, completed, rejected });
});

app.get("/api/sites", (req, res) => {
  const search = String(req.query.search ?? "").trim().toLowerCase();

  const rows = db
    .prepare(
      `SELECT * FROM sites
       WHERE (? = '') OR
         LOWER(id) LIKE ? OR LOWER(site_name) LIKE ? OR LOWER(site_code) LIKE ? OR LOWER(region) LIKE ? OR LOWER(status) LIKE ?
       ORDER BY submitted_at DESC`,
    )
    .all(
      search,
      `%${search}%`,
      `%${search}%`,
      `%${search}%`,
      `%${search}%`,
      `%${search}%`,
    );

  const payload = rows.map((row) => ({
    ...mapSiteRow(row),
    audit: getSiteAudit(row.id),
  }));

  res.json(payload);
});

app.get("/api/sites/:id", (req, res) => {
  const site = getSiteById(req.params.id);
  if (!site) {
    res.status(404).json({ message: "Site not found" });
    return;
  }

  res.json(site);
});

app.post("/api/sites", (req, res) => {
  const body = req.body ?? {};

  const requiredFields = ["siteName", "siteCode", "region", "requester", "requesterEmail"];
  const missing = requiredFields.find((key) => !String(body[key] ?? "").trim());
  if (missing) {
    res.status(400).json({ message: `Missing required field: ${missing}` });
    return;
  }

  const existing = db.prepare("SELECT id FROM sites WHERE site_code = ?").get(String(body.siteCode).toUpperCase());
  if (existing) {
    res.status(409).json({ message: "Site code already exists" });
    return;
  }

  const now = new Date().toISOString();
  const siteId = generateSiteId();

  const insertSite = db.prepare(`
    INSERT INTO sites (
      id, site_name, site_code, region, address, requester, requester_email,
      submitted_at, status, current_stage, legal_approval, compliance_approval,
      site_ops_approval, rejection_reason, version
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NULL, NULL, NULL, NULL, 1)
  `);

  const insertAudit = db.prepare(`
    INSERT INTO audit_logs (site_id, at, by_role, action, note, from_status, to_status)
    VALUES (?, ?, ?, ?, ?, ?, ?)
  `);

  const insertNotification = db.prepare(`
    INSERT INTO notification_logs (site_id, at, recipient_role, channel, message)
    VALUES (?, ?, ?, ?, ?)
  `);

  const updateStatus = db.prepare(`
    UPDATE sites
    SET status = ?, current_stage = ?, version = version + 1
    WHERE id = ?
  `);

  const tx = db.transaction(() => {
    insertSite.run(
      siteId,
      String(body.siteName).trim(),
      String(body.siteCode).trim().toUpperCase(),
      String(body.region).trim(),
      String(body.address ?? "").trim(),
      String(body.requester).trim(),
      String(body.requesterEmail).trim(),
      now,
      "Pending",
      "Legal",
    );

    insertAudit.run(siteId, now, "Requester", "Submitted", "Site onboarding request created.", "Pending", "Pending");

    updateStatus.run("Legal Pending", "Legal", siteId);

    insertAudit.run(
      siteId,
      now,
      "Requester",
      "Routed",
      "Request validated and routed to Legal queue.",
      "Pending",
      "Legal Pending",
    );

    insertNotification.run(
      siteId,
      now,
      "Legal",
      "email",
      `Pending approval for ${siteId}: Legal review is required.`,
    );
  });

  tx();

  res.status(201).json(getSiteById(siteId));
});

app.post("/api/sites/:id/decision", (req, res) => {
  const body = req.body ?? {};
  const role = String(body.role ?? "");
  const decision = String(body.decision ?? "");
  const note = String(body.note ?? "").trim();
  const version = Number(body.version ?? NaN);

  if (!allowedRoles.has(role)) {
    res.status(400).json({ message: "Invalid role" });
    return;
  }

  if (!["Approved", "Rejected"].includes(decision)) {
    res.status(400).json({ message: "Decision must be Approved or Rejected" });
    return;
  }

  if (!Number.isFinite(version)) {
    res.status(400).json({ message: "Version is required" });
    return;
  }

  const site = db.prepare("SELECT * FROM sites WHERE id = ?").get(req.params.id);
  if (!site) {
    res.status(404).json({ message: "Site not found" });
    return;
  }

  if (site.version !== version) {
    res.status(409).json({ message: "Version conflict. Please refresh and retry." });
    return;
  }

  if (!roleCanAct(role, site)) {
    res.status(403).json({ message: "Role cannot act on this stage" });
    return;
  }

  if (decision === "Rejected" && note.length < 3) {
    res.status(400).json({ message: "Rejection reason is required" });
    return;
  }

  const now = new Date().toISOString();
  const fromStatus = site.status;
  let toStatus = site.status;
  let toStage = site.current_stage;

  let legalApproval = site.legal_approval;
  let complianceApproval = site.compliance_approval;
  let siteOpsApproval = site.site_ops_approval;
  let rejectionReason = site.rejection_reason;

  if (decision === "Approved") {
    const next = nextOnApprove(site);
    toStatus = next.status;
    toStage = next.stage;

    if (site.current_stage === "Legal") legalApproval = "Approved";
    if (site.current_stage === "Compliance") complianceApproval = "Approved";
    if (site.current_stage === "SiteOps") siteOpsApproval = "Approved";

    rejectionReason = null;
  } else {
    toStatus = "Rejected";
    toStage = "Done";
    rejectionReason = note;

    if (site.current_stage === "Legal") legalApproval = "Rejected";
    if (site.current_stage === "Compliance") complianceApproval = "Rejected";
    if (site.current_stage === "SiteOps") siteOpsApproval = "Rejected";
  }

  const update = db.prepare(`
    UPDATE sites
    SET status = ?,
        current_stage = ?,
        legal_approval = ?,
        compliance_approval = ?,
        site_ops_approval = ?,
        rejection_reason = ?,
        version = version + 1
    WHERE id = ? AND version = ?
  `);

  const insertAudit = db.prepare(`
    INSERT INTO audit_logs (site_id, at, by_role, action, note, from_status, to_status)
    VALUES (?, ?, ?, ?, ?, ?, ?)
  `);

  const insertNotification = db.prepare(`
    INSERT INTO notification_logs (site_id, at, recipient_role, channel, message)
    VALUES (?, ?, ?, ?, ?)
  `);

  const tx = db.transaction(() => {
    const result = update.run(
      toStatus,
      toStage,
      legalApproval,
      complianceApproval,
      siteOpsApproval,
      rejectionReason,
      req.params.id,
      version,
    );

    if (result.changes === 0) {
      throw new Error("VERSION_CONFLICT");
    }

    insertAudit.run(req.params.id, now, role, decision, note || null, fromStatus, toStatus);

    const recipientRole = recipientRoleForPendingStatus(toStatus);
    if (recipientRole) {
      insertNotification.run(
        req.params.id,
        now,
        recipientRole,
        "email",
        `Pending approval for ${req.params.id}: ${recipientRole} review is required.`,
      );
    }
  });

  try {
    tx();
  } catch (error) {
    if (error instanceof Error && error.message === "VERSION_CONFLICT") {
      res.status(409).json({ message: "Version conflict. Please refresh and retry." });
      return;
    }
    throw error;
  }

  res.json(getSiteById(req.params.id));
});

app.get("/api/reports/monthly", (req, res) => {
  const month = String(req.query.month ?? new Date().toISOString().slice(0, 7));
  const like = `${month}%`;

  const created = db.prepare("SELECT COUNT(*) AS count FROM sites WHERE submitted_at LIKE ?").get(like)?.count ?? 0;
  const completed =
    db.prepare("SELECT COUNT(*) AS count FROM sites WHERE submitted_at LIKE ? AND status = 'Completed'").get(like)?.count ?? 0;
  const rejected =
    db.prepare("SELECT COUNT(*) AS count FROM sites WHERE submitted_at LIKE ? AND status = 'Rejected'").get(like)?.count ?? 0;

  res.json({ month, created, completed, rejected });
});

app.listen(PORT, () => {
  console.log(`API running on http://localhost:${PORT}`);
});
