# Site Onboarding Tracker

Working assessment implementation for "Rebuild the Site-Onboarding Tracker".

## What This Solves

- Replaces Excel row updates with API + database records.
- Replaces email-reply approvals with in-app role-based approve/reject actions.
- Maintains a full audit trail (who, what, when, from-status, to-status).
- Prevents stale-overwrite issues with version-based optimistic concurrency.
- Produces monthly summary from live database data.

## Tech Stack

- Frontend: React + TypeScript + Vite
- Backend: Node.js + Express
- Database: SQLite (better-sqlite3)

## Workflow

1. Requester submits new site.
2. Backend creates site with initial status Pending.
3. Site is routed to Legal Pending.
4. Legal approves/rejects.
5. On approve: moves to Compliance Pending.
6. Compliance approves/rejects.
7. On approve: moves to Site Ops Pending.
8. Site Ops approves/rejects.
9. On approve: moves to Completed.
10. Any reject: moves to Rejected with mandatory reason.

## Run Locally

1. Install dependencies

```bash
npm install
```

2. Run API and UI together

```bash
npm run dev:all
```

3. Open UI

```text
http://localhost:5173
```

API runs on:

```text
http://localhost:4000
```

## Build

```bash
npm run build
```

## API Endpoints

- `GET /api/health`
- `GET /api/dashboard`
- `GET /api/sites?search=...`
- `GET /api/sites/:id`
- `POST /api/sites`
- `POST /api/sites/:id/decision`
- `GET /api/reports/monthly?month=YYYY-MM`

## Notes For Reviewers

- Database file is created automatically at `data/onboard-tracker.db`.
- Initial sample data is seeded on first run.
- Pending-stage email notifications are implemented as mock notification log entries.
- Decision API enforces:
  - Role-stage authorization
  - Mandatory rejection reason
  - Version conflict checks (optimistic locking)

## Scope Assumptions

- Enterprise authentication/SSO (Okta or company identity provider) is intentionally out of scope for this assessment.
- User login is represented using role-based user simulation in UI and backend to demonstrate stage-based authorization behavior.
