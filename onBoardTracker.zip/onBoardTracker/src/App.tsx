import { useEffect, useMemo, useState } from "react";

type Role = "Requester" | "Legal" | "Compliance" | "SiteOps";

type SiteStatus =
  | "Pending"
  | "Legal Pending"
  | "Compliance Pending"
  | "Site Ops Pending"
  | "Completed"
  | "Rejected";

type AuditEntry = {
  at: string;
  by: Role;
  action: string;
  note?: string;
  fromStatus: SiteStatus;
  toStatus: SiteStatus;
};

type SiteRecord = {
  id: string;
  siteName: string;
  siteCode: string;
  region: string;
  address: string;
  requester: string;
  requesterEmail: string;
  submittedAt: string;
  status: SiteStatus;
  currentStage: "Legal" | "Compliance" | "SiteOps" | "Done";
  legalApproval?: "Approved" | "Rejected";
  complianceApproval?: "Approved" | "Rejected";
  siteOpsApproval?: "Approved" | "Rejected";
  rejectionReason?: string;
  version: number;
  audit: AuditEntry[];
};

type Dashboard = {
  total: number;
  pending: number;
  completed: number;
  rejected: number;
};

type MonthlyReport = {
  month: string;
  created: number;
  completed: number;
  rejected: number;
};

function roleCanAct(role: Role, site: SiteRecord) {
  if (site.status === "Completed" || site.status === "Rejected") {
    return false;
  }

  return (
    (site.currentStage === "Legal" && role === "Legal") ||
    (site.currentStage === "Compliance" && role === "Compliance") ||
    (site.currentStage === "SiteOps" && role === "SiteOps")
  );
}

function App() {
  const [currentRole, setCurrentRole] = useState<Role>("Requester");
  const [sites, setSites] = useState<SiteRecord[]>([]);
  const [selectedSiteId, setSelectedSiteId] = useState<string>("");
  const [decisionNote, setDecisionNote] = useState("");
  const [message, setMessage] = useState("");
  const [search, setSearch] = useState("");
  const [loading, setLoading] = useState(true);
  const [dashboard, setDashboard] = useState<Dashboard>({ total: 0, pending: 0, completed: 0, rejected: 0 });
  const [monthly, setMonthly] = useState<MonthlyReport>({ month: "", created: 0, completed: 0, rejected: 0 });

  const [form, setForm] = useState({
    siteName: "",
    siteCode: "",
    region: "",
    address: "",
    requester: "",
    requesterEmail: "",
  });

  const selectedSite = useMemo(() => sites.find((item) => item.id === selectedSiteId) ?? null, [sites, selectedSiteId]);

  async function refreshSites(searchText = search) {
    const query = searchText.trim() ? `?search=${encodeURIComponent(searchText)}` : "";
    const response = await fetch(`/api/sites${query}`);
    if (!response.ok) {
      throw new Error("Failed to fetch sites");
    }
    const payload = (await response.json()) as SiteRecord[];
    setSites(payload);

    if (!selectedSiteId && payload.length > 0) {
      setSelectedSiteId(payload[0].id);
      return;
    }

    if (selectedSiteId && !payload.some((item) => item.id === selectedSiteId)) {
      setSelectedSiteId(payload[0]?.id ?? "");
    }
  }

  async function refreshDashboard() {
    const response = await fetch("/api/dashboard");
    if (!response.ok) {
      throw new Error("Failed to fetch dashboard");
    }
    const payload = (await response.json()) as Dashboard;
    setDashboard(payload);
  }

  async function refreshMonthly() {
    const response = await fetch("/api/reports/monthly");
    if (!response.ok) {
      throw new Error("Failed to fetch monthly report");
    }
    const payload = (await response.json()) as MonthlyReport;
    setMonthly(payload);
  }

  async function refreshAll(searchText = search) {
    await Promise.all([refreshSites(searchText), refreshDashboard(), refreshMonthly()]);
  }

  useEffect(() => {
    const load = async () => {
      try {
        setLoading(true);
        await refreshAll();
      } catch (error) {
        setMessage(error instanceof Error ? error.message : "Failed to load data");
      } finally {
        setLoading(false);
      }
    };

    void load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    const id = window.setTimeout(() => {
      void refreshSites(search).catch(() => {
        setMessage("Failed to filter sites");
      });
    }, 250);

    return () => window.clearTimeout(id);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [search]);

  const submitSite = async () => {
    if (
      !form.siteName.trim() ||
      !form.siteCode.trim() ||
      !form.region.trim() ||
      !form.requester.trim() ||
      !form.requesterEmail.trim()
    ) {
      setMessage("Please fill all mandatory fields before submitting.");
      return;
    }

    try {
      const response = await fetch("/api/sites", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form),
      });

      const payload = await response.json();
      if (!response.ok) {
        throw new Error(payload.message ?? "Failed to submit site");
      }

      const created = payload as SiteRecord;
      setSelectedSiteId(created.id);
      setForm({
        siteName: "",
        siteCode: "",
        region: "",
        address: "",
        requester: "",
        requesterEmail: "",
      });
      await refreshAll();
      setMessage(`Site ${created.id} submitted and moved to Legal Pending.`);
    } catch (error) {
      setMessage(error instanceof Error ? error.message : "Failed to submit site");
    }
  };

  const applyDecision = async (decision: "Approved" | "Rejected") => {
    if (!selectedSite) {
      setMessage("Select a site first.");
      return;
    }

    if (!roleCanAct(currentRole, selectedSite)) {
      setMessage("Your role does not have permission for this stage.");
      return;
    }

    if (decision === "Rejected" && !decisionNote.trim()) {
      setMessage("Rejection reason is mandatory.");
      return;
    }

    try {
      const response = await fetch(`/api/sites/${selectedSite.id}/decision`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          role: currentRole,
          decision,
          note: decisionNote,
          version: selectedSite.version,
        }),
      });

      const payload = await response.json();
      if (!response.ok) {
        throw new Error(payload.message ?? "Failed to apply decision");
      }

      const updated = payload as SiteRecord;
      setSites((prev) => prev.map((item) => (item.id === updated.id ? updated : item)));
      await Promise.all([refreshDashboard(), refreshMonthly()]);
      setMessage(`Site ${updated.id} is now ${updated.status}.`);
      setDecisionNote("");
    } catch (error) {
      setMessage(error instanceof Error ? error.message : "Failed to apply decision");
    }
  };

  return (
    <div className="app-shell">
      <header className="hero">
        <div>
          <h1>Site Onboarding Tracker</h1>
          <p>Single source of truth for submission, staged approvals, audit trail, and reporting.</p>
        </div>
        <div className="role-box">
          <label htmlFor="role">Login as</label>
          <select id="role" value={currentRole} onChange={(e) => setCurrentRole(e.target.value as Role)}>
            <option>Requester</option>
            <option>Legal</option>
            <option>Compliance</option>
            <option>SiteOps</option>
          </select>
        </div>
      </header>

      <section className="cards-grid">
        <article className="metric">
          <h3>Total Sites</h3>
          <strong>{dashboard.total}</strong>
        </article>
        <article className="metric">
          <h3>Pending</h3>
          <strong>{dashboard.pending}</strong>
        </article>
        <article className="metric">
          <h3>Completed</h3>
          <strong>{dashboard.completed}</strong>
        </article>
        <article className="metric">
          <h3>Rejected</h3>
          <strong>{dashboard.rejected}</strong>
        </article>
      </section>

      <main className="layout">
        <section className="panel">
          <h2>Submit New Site</h2>
          <div className="form-grid">
            <label>
              Site Name*
              <input value={form.siteName} onChange={(e) => setForm((p) => ({ ...p, siteName: e.target.value }))} />
            </label>
            <label>
              Site Code*
              <input value={form.siteCode} onChange={(e) => setForm((p) => ({ ...p, siteCode: e.target.value }))} />
            </label>
            <label>
              Region*
              <input value={form.region} onChange={(e) => setForm((p) => ({ ...p, region: e.target.value }))} />
            </label>
            <label>
              Address
              <input value={form.address} onChange={(e) => setForm((p) => ({ ...p, address: e.target.value }))} />
            </label>
            <label>
              Requester Name*
              <input value={form.requester} onChange={(e) => setForm((p) => ({ ...p, requester: e.target.value }))} />
            </label>
            <label>
              Requester Email*
              <input
                type="email"
                value={form.requesterEmail}
                onChange={(e) => setForm((p) => ({ ...p, requesterEmail: e.target.value }))}
              />
            </label>
          </div>
          <button className="btn btn-primary" type="button" onClick={() => void submitSite()}>
            Submit Site
          </button>
          {message && <p className="message">{message}</p>}
        </section>

        <section className="panel">
          <div className="panel-head">
            <h2>Sites Queue</h2>
            <input placeholder="Search by name/code/status" value={search} onChange={(e) => setSearch(e.target.value)} />
          </div>

          <div className="table-wrap">
            <table>
              <thead>
                <tr>
                  <th>ID</th>
                  <th>Site</th>
                  <th>Region</th>
                  <th>Status</th>
                  <th>Stage</th>
                </tr>
              </thead>
              <tbody>
                {sites.map((site) => (
                  <tr
                    key={site.id}
                    className={site.id === selectedSiteId ? "row-active" : ""}
                    onClick={() => setSelectedSiteId(site.id)}
                  >
                    <td>{site.id}</td>
                    <td>{site.siteName}</td>
                    <td>{site.region}</td>
                    <td>{site.status}</td>
                    <td>{site.currentStage}</td>
                  </tr>
                ))}
                {!loading && sites.length === 0 && (
                  <tr>
                    <td colSpan={5}>No sites found.</td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </section>

        <section className="panel">
          <h2>Approval Workspace</h2>
          {!selectedSite && <p>Select any site from queue.</p>}

          {selectedSite && (
            <>
              <div className="site-summary">
                <p>
                  <strong>{selectedSite.siteName}</strong> ({selectedSite.siteCode})
                </p>
                <p>Status: {selectedSite.status}</p>
                <p>Current Stage: {selectedSite.currentStage}</p>
                <p>Version: {selectedSite.version}</p>
                {selectedSite.rejectionReason && <p>Reason: {selectedSite.rejectionReason}</p>}
              </div>

              <label>
                Approval/Rejection Note
                <textarea value={decisionNote} onChange={(e) => setDecisionNote(e.target.value)} rows={3} />
              </label>

              <div className="action-row">
                <button
                  className="btn btn-success"
                  type="button"
                  disabled={!roleCanAct(currentRole, selectedSite)}
                  onClick={() => void applyDecision("Approved")}
                >
                  Approve
                </button>
                <button
                  className="btn btn-danger"
                  type="button"
                  disabled={!roleCanAct(currentRole, selectedSite)}
                  onClick={() => void applyDecision("Rejected")}
                >
                  Reject
                </button>
              </div>

              {!roleCanAct(currentRole, selectedSite) && (
                <p className="hint">Current role cannot act on this stage. Login with the matching role.</p>
              )}
            </>
          )}
        </section>

        <section className="panel">
          <h2>Audit Trail</h2>
          {!selectedSite && <p>Select a site to view audit history.</p>}

          {selectedSite && (
            <ul className="audit-list">
              {selectedSite.audit.map((entry, idx) => (
                <li key={`${entry.at}-${idx}`}>
                  <p>
                    <strong>{entry.at}</strong> | {entry.by} | {entry.action}
                  </p>
                  <p>
                    {entry.fromStatus} {" -> "} {entry.toStatus}
                  </p>
                  {entry.note && <p>Note: {entry.note}</p>}
                </li>
              ))}
            </ul>
          )}
        </section>

        <section className="panel">
          <h2>Monthly Report Snapshot</h2>
          <p>
            Month: {monthly.month || "-"}
            <br />
            Created: {monthly.created}
            <br />
            Completed: {monthly.completed}
            <br />
            Rejected: {monthly.rejected}
          </p>
        </section>
      </main>
    </div>
  );
}

export default App;
